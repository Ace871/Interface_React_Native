import * as React from 'react';
import { Text, View, StyleSheet, Image, TextInput, Button, Title } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Login Screen
      </Text>
      <Image style={styles.logo} source={require('../assets/profile_logo.jpg')} />
      
      <TextInput style={styles.textbox}
      placeholder="Usuário:"/>
      
      <TextInput style={styles.textbox}
      placeholder="Senha:"/>

      <Button title="Registrar-se" color='#dc143c'/>
      <Button title="Logar" color='#5f9ea0'/>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  logo: {
    height: 128,
    width: 128,
    margin: 10
  },
  textbox: {
    marginTop: 5,
    fontSize:15,
    marginBottom: 5,
    borderWidth: 1,
    padding: 3,
    backgroundColor: `#ffffff`
  },
  paragraph: {
    margin: 1,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    color: `#f0f8ff`,
  },
});
